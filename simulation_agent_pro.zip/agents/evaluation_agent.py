
class EvaluationAgent:
    def evaluate(self, results):
        best = max(results, key=lambda x:x[1])
        print("[Eval]", best)
        return best

    def need_optimization(self, best, threshold=-0.01):
        return best[1] < threshold

    def generate_new_range(self, p):
        d=0.05
        return (max(0,p-d), min(1,p+d))
