
class TaskParserAgent:
    def parse(self, config):
        return {
            "frequency_range": tuple(config["freq"]),
            "param_range": tuple(config["param"]),
            "steps": ["build","mesh","solve","analyze"]
        }
