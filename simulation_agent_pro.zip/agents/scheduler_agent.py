
from core.simulation_runner import run_simulation
from concurrent.futures import ThreadPoolExecutor

class SchedulerAgent:
    def execute(self, task, workers=2):
        p_min, p_max = task["param_range"]
        params = [p_min + i*(p_max-p_min)/10 for i in range(11)]

        results = []
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = [executor.submit(run_simulation, p) for p in params]
            for f,p in zip(futures, params):
                results.append((p, f.result()))

        return results
