
import time, random
from utils.logger import log

def run_simulation(param):
    log(f"运行仿真 param={param:.3f}")
    time.sleep(0.1)
    return -(param-0.6)**2 + random.uniform(-0.01,0.01)
