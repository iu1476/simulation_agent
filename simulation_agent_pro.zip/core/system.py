
from agents.parser_agent import TaskParserAgent
from agents.scheduler_agent import SchedulerAgent
from agents.evaluation_agent import EvaluationAgent
from utils.logger import log

class SimulationSystem:
    def __init__(self):
        self.parser = TaskParserAgent()
        self.scheduler = SchedulerAgent()
        self.evaluator = EvaluationAgent()

    def run(self, config):
        log("系统启动")

        task = self.parser.parse(config)

        for i in range(config.get("max_iter", 3)):
            log(f"===== 第 {i+1} 轮 =====")

            results = self.scheduler.execute(task, workers=config.get("workers",2))
            best = self.evaluator.evaluate(results)

            if not self.evaluator.need_optimization(best):
                log("达到目标，停止")
                break

            task["param_range"] = self.evaluator.generate_new_range(best[0])

        log(f"最终结果: {best}")
